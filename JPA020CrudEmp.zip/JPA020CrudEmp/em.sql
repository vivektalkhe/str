select * from emp;

delete from EMP where empNo=1111;

delete from EMP where empNo in(18,12);

select * from emp;

