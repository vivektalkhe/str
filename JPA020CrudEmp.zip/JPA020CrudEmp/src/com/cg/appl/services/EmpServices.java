package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;


public interface EmpServices {
	Emp getEmpDetails(int empNo) throws EmpException;
	
	List<Emp> getEmpList() throws EmpException;
	
	Emp admitNewEmp(Emp emp) throws EmpException;
	
	boolean updateName(int empNo,String newName)throws EmpException;
	
	public boolean updateEmp(Emp emp) throws EmpException;
	
	boolean deleteEmp(int empNo) throws EmpException;
}
