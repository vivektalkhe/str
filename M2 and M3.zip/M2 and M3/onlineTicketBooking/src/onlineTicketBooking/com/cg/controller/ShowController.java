/*********************************************************************
 * File                 : ShowController.java
 * Author Name          : ROHIT SINGH SAWAN
 * Desc                 : JAVA servlet(controller) which manages the flow of control throughout the application life cycle.
 *                        separates the presentation and the business logic.
 * Version              : 1.0
 * Creation Date        : 14-Mar-2017
 * Last Modified Date   : 14-Mar-2017
 *********************************************************************/



package onlineTicketBooking.com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import onlineTicketBooking.com.cg.exceptions.UserException;
import onlineTicketBooking.com.cg.dto.Show;
import onlineTicketBooking.com.cg.service.IShowService;
import onlineTicketBooking.com.cg.service.ShowServiceImpl;

@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IShowService service;                               //reference variable of Service Interface

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String path = request.getServletPath();
		System.out.println(path);
		service = new ShowServiceImpl();           //object of Service class  

		if (path.equals("/showDetails.do")) {
			
		HttpSession session=request.getSession(true);	
			try {
				List<Show> myList = service.getShowDetails();
				RequestDispatcher req = request
						.getRequestDispatcher("/showDetails.jsp");
				request.setAttribute("show", myList);
				req.forward(request, response);
			} catch (UserException e) {
				RequestDispatcher req = request.getRequestDispatcher("/error.jsp");
				request.setAttribute("error",e);
			}
		}

		if (path.equals("/book.do")) {

			String data = request.getQueryString();          //to retrieve the showId from browser
			String showId = data.substring(3, 7);
			System.out.println(showId);

			Show show;
			try {
				show = service.getShow(showId);
				RequestDispatcher req = request
						.getRequestDispatcher("/bookNow.jsp");
				request.setAttribute("showId", show.getShowId());
				request.setAttribute("showName", show.getShowName());
				request.setAttribute("price", show.getTicketPrice());
				request.setAttribute("seatsAvailable", show.getAvailableSeats());
				req.forward(request, response);
			} catch (UserException e) {
				RequestDispatcher req = request.getRequestDispatcher("/error.jsp");
				request.setAttribute("error",e);
			}

			
		}

		if (path.equals("/bookNow.do")) {

			String data = request.getQueryString();
			String showId = data.substring(3, 7);
			System.out.println(showId);
			String showName=request.getParameter("showName");
			String seats = request.getParameter("seatsToBook");
			System.out.println(seats);
			int seatsToBook = Integer.parseInt(seats);
			System.out.println(seatsToBook);
			String customerName = request.getParameter("customerName");
			String mobileNo = request.getParameter("mobileNo");
			String price = request.getParameter("price");
			double pricePerTicket = Double.parseDouble(price);
			double totalAmount = pricePerTicket * seatsToBook;
			boolean b;
			try {
				b = service.updateShowDetails(showId, seatsToBook);   //returns true if available seats updated successfully
				if (b == true) {           
					
					System.out.println("record updated successfully");
					RequestDispatcher req = request.getRequestDispatcher("/success.jsp"); //to show booking details to customer 
					request.setAttribute("showName",showName);
					request.setAttribute("customerName",customerName);
					request.setAttribute("mobileNo",mobileNo);
					request.setAttribute("noOfSeats",seatsToBook);
					request.setAttribute("totalPrice",totalAmount);
					req.forward(request, response);
				}
			} catch (UserException e) {
				RequestDispatcher req = request.getRequestDispatcher("/error.jsp");
				request.setAttribute("error",e);
			}

		}

	}
}
