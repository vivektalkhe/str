package onlineTicketBooking.com.cg.dto;

import java.time.LocalDate;

public class Show {

	private String showId;
	private String showName;
	private String location;
	private LocalDate date;
	private int availableSeats;
	private double ticketPrice;

	public Show() {
		super();
	}

	public Show(String showId, String showName, String location,
			LocalDate date, int availableSeats, double ticketPrice) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.date = date;
		this.availableSeats = availableSeats;
		this.ticketPrice = ticketPrice;
	}

	@Override
	public String toString() {
		return "Show [showId=" + showId + ", showName=" + showName
				+ ", location=" + location + ", date=" + date
				+ ", availableSeats=" + availableSeats + ", ticketPrice="
				+ ticketPrice + "]";
	}

	public String getShowId() {
		return showId;
	}

	public void setShowId(String showId) {
		this.showId = showId;
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

}
