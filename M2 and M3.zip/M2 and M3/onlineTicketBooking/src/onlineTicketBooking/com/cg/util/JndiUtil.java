package onlineTicketBooking.com.cg.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


import onlineTicketBooking.com.cg.exceptions.UserException;


public class JndiUtil {

	private DataSource dataSource;

	public JndiUtil() throws UserException {
		Context ctx;
		try {
			ctx = new InitialContext();
			dataSource = (DataSource) ctx.lookup("java:/OracleDS");
		} catch (NamingException e) {
			throw new UserException(" Failed to get JNDI context");
		} 
		
	}

	public Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}
}
