package onlineTicketBooking.com.cg.dao;

import java.util.List;

import onlineTicketBooking.com.cg.exceptions.UserException;
import onlineTicketBooking.com.cg.dto.Show;

public interface IShowDao {
	public List<Show> getShowDetails() throws UserException;
	public Show getShow(String showId) throws UserException;
	public boolean updateShowDetails(String showId,int seats) throws UserException;
}
