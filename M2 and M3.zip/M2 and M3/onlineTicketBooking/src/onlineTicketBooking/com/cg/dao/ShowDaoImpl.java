package onlineTicketBooking.com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import onlineTicketBooking.com.cg.exceptions.UserException;
import onlineTicketBooking.com.cg.dto.Show;
import onlineTicketBooking.com.cg.util.JndiUtil;

public class ShowDaoImpl implements IShowDao {

	Connection connect = null;
	PreparedStatement stmt = null;
	private JndiUtil util;

	@Override
	public List<Show> getShowDetails() throws UserException{

		List<Show> myList = new ArrayList<Show>();
		
		try {
			util = new JndiUtil();
			connect = util.getConnection();
			String qry = "select * from ShowDetails ";
			stmt = connect.prepareStatement(qry);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				String showId = rs.getString(1);
				String showName = rs.getString(2);
				String location = rs.getString(3);
				java.sql.Date date01 = rs.getDate(4);
				LocalDate date = date01.toLocalDate();
				int availableSeats = rs.getInt(5);
				double ticketPrice = rs.getDouble(6);
				Show show = new Show(showId, showName, location, date,
						availableSeats, ticketPrice);
				myList.add(show);
			}
		} catch (SQLException e) {
			throw new UserException("Connection Failed");
		}

		return myList;
	}

	@Override
	public Show getShow(String showId) throws UserException {
		
		
		Show show=null;
		try {
			util = new JndiUtil();
			connect = util.getConnection();
			String qry = "select * from ShowDetails where showId=?";
			stmt = connect.prepareStatement(qry);
			stmt.setString(1, showId);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {

				String showName = rs.getString(2);
				String location = rs.getString(3);
				java.sql.Date date01 = rs.getDate(4);
				LocalDate date = date01.toLocalDate();
				int availableSeats = rs.getInt(5);
				double ticketPrice = rs.getDouble(6);
				show = new Show(showId, showName, location, date,
						availableSeats, ticketPrice);
			}
		} catch (SQLException e) {
			throw new UserException("Connection Failed");
		}
	
		return show;
	}

	@Override
	public boolean updateShowDetails(String showId, int seats) throws UserException {
		
		try {
			util = new JndiUtil();
			connect = util.getConnection();
			String qry = "update ShowDetails set AvSeats=AvSeats-? where showId=?";
			stmt = connect.prepareStatement(qry);
			stmt.setInt(1,seats);
			stmt.setString(2, showId);
			int result=stmt.executeUpdate();
			if(result!=0){
				return true;
			}
		} catch (SQLException e) {
			throw new UserException("Failed to Book Ticket");
		}
	
	return false;
	
	}
}
