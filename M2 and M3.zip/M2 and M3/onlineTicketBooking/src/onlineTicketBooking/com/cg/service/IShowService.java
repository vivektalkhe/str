package onlineTicketBooking.com.cg.service;

import java.util.List;

import onlineTicketBooking.com.cg.exceptions.UserException;
import onlineTicketBooking.com.cg.dto.Show;

public interface IShowService {

	public Show getShow(String showId) throws UserException;
	public List<Show> getShowDetails() throws UserException;
	public boolean updateShowDetails(String showId,int seats) throws UserException;
}
