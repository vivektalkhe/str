package onlineTicketBooking.com.cg.service;

import java.util.List;

import onlineTicketBooking.com.cg.exceptions.UserException;
import onlineTicketBooking.com.cg.dao.IShowDao;
import onlineTicketBooking.com.cg.dao.ShowDaoImpl;
import onlineTicketBooking.com.cg.dto.Show;

public class ShowServiceImpl implements IShowService {

	IShowDao dao;

	public ShowServiceImpl() {
		dao = new ShowDaoImpl();
	}

	
	@Override
	public List<Show> getShowDetails() throws UserException {
		return dao.getShowDetails();

	}

	@Override
	public Show getShow(String showId) throws UserException {
		return dao.getShow(showId);
	}


	@Override
	public boolean updateShowDetails(String showId, int seats) throws UserException {
		return dao.updateShowDetails(showId, seats);
	}

}
