
select * from ShowDetails;


update showdetails set avseats=30 where showid='S102';