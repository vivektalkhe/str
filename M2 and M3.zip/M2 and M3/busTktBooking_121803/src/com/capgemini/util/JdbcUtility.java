package com.capgemini.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class JdbcUtility {
	private static final Logger mylogger=Logger.getLogger(JdbcUtility.class);
	public static Properties loadProperty() {
		Properties prop = new Properties();
		InputStream in = null;
		try {
			in = new FileInputStream("jdbcsample.properties");
			try {
				prop.load(in);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prop;
	}

	public static Connection getConnection(){
		Connection con = null;
		Properties prop = loadProperty();
		String url = prop.getProperty("url");
		String driver = prop.getProperty("driver");
		String uname = prop.getProperty("uname");
		String upass = prop.getProperty("upass");
	
		try {
			Class.forName(driver);
			//System.out.println("driver Set");
			mylogger.info("Driver is loaded");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			mylogger.error("Driver not loaded");
		}
		try {
			con = DriverManager.getConnection(url, uname, upass);
			if (con != null) {
				//System.out.println("connected");
				mylogger.info("Connected to the database");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			mylogger.error("Not Connected");
			
		}
		return con;
	}
	
	
	/*public static void main(String args[]) {
		JdbcUtility j=new JdbcUtility();
		PropertyConfigurator.configure("Log4j.properties");
		try {
			j.getConnection();
		} catch (MobileExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
}
