package com.capgemini.service;
import com.capgemini.bean.*;
import com.capgemini.exception.BookingException;

import java.util.ArrayList;

public interface BusService {
	ArrayList<BusBean> retrieveBusDetails();
	int bookTicket(BookingBean bookingBean) throws BookingException;

}
