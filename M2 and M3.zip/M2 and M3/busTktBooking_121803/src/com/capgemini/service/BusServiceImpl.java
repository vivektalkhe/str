package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;

public class BusServiceImpl implements BusService {

	BusDao obj;                       

	@Override
	public ArrayList<BusBean> retrieveBusDetails() {
		obj = new BusDaoImpl();                              
		ArrayList<BusBean> blist = new ArrayList<BusBean>();
		blist = obj.retrieveBusDetails();
		return blist;

	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		obj = new BusDaoImpl();  
		int booking_id=obj.bookTicket(bookingBean);
		return booking_id;
	}

}
