package com.capgemini.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;

public class TestBusDaoImpl {

	BusDao b;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	
	}

	@Before
	public void setUp() throws Exception {
	b=new BusDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		b=null;
	}

	@Test
	public void testRetrieveBusDetails() {
		assertNotNull(b.retrieveBusDetails());
	}

	

	

}
