
/*********************************************************************
 * File                 : BusDaoImpl.java
 * Author Name          : ROHIT SINGH SAWAN
 * Description          : includes functions for the implementation of bus booking system
 * Version              : 1.0
 * Creation Date        : 01-Mar-2017
 * Last Modified Date   : 01-Mar-2017
 *********************************************************************/






package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.JdbcUtility;

public class BusDaoImpl implements BusDao {

	private final static Logger mylogger = Logger.getLogger(BusDaoImpl.class);

	Connection con;
	PreparedStatement pst;

	@Override
	public ArrayList<BusBean> retrieveBusDetails() {

		con = JdbcUtility.getConnection();
		String query = "select * from BusDetails";

		ArrayList<BusBean> blist = new ArrayList<BusBean>();
		try {
			pst = con.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {

				int bus_id = rs.getInt(1);
				String bus_type = rs.getString(2);
				// LocalDate dateOfJourney = rs.getDate(7);

				java.sql.Date dateOfJourney = rs.getDate(7);

				String fromStop = rs.getString(3);
				String toStop = rs.getString(4);
				int availableSeats = rs.getInt(6);
				int fare = rs.getInt(5);
				BusBean b = new BusBean();
				b.setBusid(bus_id);
				b.setBusType(bus_type);
				b.setFromStop(fromStop);
				b.setToStop(toStop);
				b.setFare(fare);
				b.setAvailableSeats(availableSeats);
				b.setDateOfJourney(dateOfJourney);
				blist.add(b);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		mylogger.info("list showed successfully");
		return blist;
	}

	@Override
	public int bookTicket(BookingBean bookingbean) throws BookingException {

		int noOfSeats = bookingbean.getNoOfSeats();
		int busid = bookingbean.getBusid();
		String custid = bookingbean.getCustId();

		con = JdbcUtility.getConnection();

		int count = 0;
		int rec = 0;
		int bookid;
		try {
			String query01 = "select availableSeats from BusDetails where busId=?";
			pst = con.prepareStatement(query01);
			pst.setInt(1, busid);
			ResultSet rs = pst.executeQuery();
			rs.next();
			count = rs.getInt(1);

			if (count < noOfSeats) {
				throw new BookingException(" Sorry no seats Available");

			} else {

				String query02 = "insert into  BookingDetails values(Booking_Id_Seq.nextval,?,?,?)";
				pst = con.prepareStatement(query02);
				pst.setString(1, custid);
				pst.setInt(2, busid);
				pst.setInt(3, noOfSeats);
				rec = pst.executeUpdate();
				if (rec > 0) {
					System.out.println("record inserted into bookingdeails");
					boolean b = updateBusDao(busid, noOfSeats);
					if (b == true) {
						String query03 = "select bookingId from BookingDetails where custId=? ";
						pst = con.prepareStatement(query03);
						pst.setString(1, custid);
						ResultSet rs1 = pst.executeQuery();

						rs1.next();
						bookid = rs1.getInt(1);
						return bookid;
					} else {
						System.out.println("updating busDao failed");
						return 0;
					}
				}
			}
			return 0;
		} catch (SQLException e) {
			System.out.println("Enter correct details");
			e.printStackTrace();
			return 0;
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public boolean updateBusDao(int busid, int noOfSeats) {
		con = JdbcUtility.getConnection();
		int rec = 0;

		String query04 = "update BusDetails set availableSeats=availableSeats-? where busId=?";
		try {
			pst = con.prepareStatement(query04);
			pst.setInt(1, noOfSeats);
			pst.setInt(2, busid);
			rec = pst.executeUpdate();
			if (rec > 0) {

				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			System.out.println("error is here");
			e.printStackTrace();
			return false;
		}

	}

}
