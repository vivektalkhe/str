package com.capgemini.dao;
import java.util.ArrayList;
import com.capgemini.exception.*;
import com.capgemini.bean.*;

public interface BusDao {
	ArrayList<BusBean> retrieveBusDetails();
	int bookTicket(BookingBean bookingbean) throws BookingException;
	

}
