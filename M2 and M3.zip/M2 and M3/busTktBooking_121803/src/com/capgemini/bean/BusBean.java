package com.capgemini.bean;

import java.time.LocalDate;

public class BusBean {

	@Override
	public String toString() {
		return "BusBean [busid=" + busid + ", busType=" + busType
				+  ", fromStop=" + fromStop
				+ ", toStop=" + toStop + ", availableSeats=" + availableSeats
				+ ", fare=" + fare + ", dateOfJourney=" + dateOfJourney + "]";
	}
	public java.sql.Date getDateOfJourney() {
		return dateOfJourney;
	}
	public void setDateOfJourney(java.sql.Date dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}
	public int getBusid() {
		return busid;
	}
	public void setBusid(int busid) {
		this.busid = busid;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}

	public String getFromStop() {
		return fromStop;
	}
	public void setFromStop(String fromStop) {
		this.fromStop = fromStop;
	}
	public String getToStop() {
		return toStop;
	}
	public void setToStop(String toStop) {
		this.toStop = toStop;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	private int busid;
	private String busType;
	private java.sql.Date dateOfJourney;
	private String fromStop;
	private String toStop;
	private int availableSeats;
	private int fare;
	
}
