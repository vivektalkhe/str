package com.capgemini.bean;

public class BookingBean {
	

	


	@Override
	public String toString() {
		return "BookingBean [bookingId=" + bookingId + ", noOfSeats="
				+ noOfSeats + ", busid=" + busid + ", custId=" + custId + "]";
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public int getBusid() {
		return busid;
	}
	public void setBusid(int busid) {
		this.busid = busid;
	}
	
	

	private int bookingId;
	private int noOfSeats;
	private int busid;
	private String custId;

}
