/*********************************************************************
 * File                 : BookingException.java
 * Author Name          : ROHIT SINGH SAWAN
 * Description          : custom Exception to be shown if not enough seats are available
 * Version              : 1.0
 * Creation Date        : 01-Mar-2017
 * Last Modified Date   : 01-Mar-2017
 *********************************************************************/


package com.capgemini.exception;

public class BookingException extends Exception{
	String s;

	public BookingException(String s) {
		System.out.println(s);
	}

}
