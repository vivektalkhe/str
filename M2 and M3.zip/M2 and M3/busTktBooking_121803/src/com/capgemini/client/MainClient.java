/*********************************************************************
 * File                 : MainClient.java
 * Author Name          : ROHIT SINGH SAWAN
 * Description          : Main application file for user
 * Version              : 1.0
 * Creation Date        : 01-Mar-2017
 * Last Modified Date   : 01-Mar-2017
 *********************************************************************/




package com.capgemini.client;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.BusService;
import com.capgemini.service.BusServiceImpl;


public class MainClient {
	private  final static Logger mylogger=Logger.getLogger(MainClient.class);
	
	public static void main(String[] args) {

		mylogger.info("Application Started");
		ArrayList<BusBean> blist = new ArrayList<BusBean>();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice");
		int ch;
		
		BusService b = new BusServiceImpl();

		do {

			System.out
					.println("1 To SHOW ALL BUS DETAILS\n2 To BOOK TICKET\n3 To EXIT");
			System.out.println("Enter your choice");
			ch = sc.nextInt();

			switch (ch) {
			
			case 1:
				System.out.println("List of buses available");
				blist = b.retrieveBusDetails();
				for (BusBean busbean : blist) {
					System.out.println(busbean);
				}
				break;
			
			case 2:
				int bookingid=0;
				String custid;
				int busid;
				int no_of_seats;
				boolean boo;
				do {
					System.out.println("Enter Customer id");
					 custid=sc.next();
					Pattern pattern = Pattern.compile("(^[A-Z]{1,1})([0-9]{6,6})");
					Matcher matcher = pattern.matcher(custid);
					boo = matcher.matches();
				if(!boo){
					System.out.println("enter valid customer id");
				}
				} while (boo != true);
				
				
				
			
				System.out.println("enter bus id");
                 busid=sc.nextInt();
                System.out.println("Enter no.of seats required");
				 no_of_seats=sc.nextInt();
                BookingBean bookingbean=new BookingBean();
				bookingbean.setBookingId(0);   // randomly 0 as it will be system generated
				bookingbean.setBusid(busid);
				bookingbean.setCustId(custid);
				bookingbean.setNoOfSeats(no_of_seats);
				try {
					bookingid=b.bookTicket(bookingbean);
				   if(bookingid!=0){
					System.out.println("Thank you. Your booking id is: "+ bookingid);
				}
				   else{
					   System.out.println("//booking failed");
				   }
				}catch (BookingException e) {
					System.out.println("booking failed");
				}
				
				break;
			
			case 3:
				break;
			}
		} while (ch != 3);
		mylogger.info("Application Closed.");
		System.out.println("Application Closed.");
	}

}
