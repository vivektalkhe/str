package com.cg.mobilepurchasesystem.exception;

public class MobileException extends Exception{
	
	public MobileException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public MobileException(String msg)
	{
		super(msg);
	}
	

}
