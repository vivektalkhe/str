package com.cg.mobilepurchasesystem.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilepurchasesystem.dao.IMobileDao;
import com.cg.mobilepurchasesystem.dao.MobileDaoImpl;
import com.cg.mobilepurchasesystem.exception.MobileException;

public class TestMobileDaoImpl {

	IMobileDao imobile;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		imobile=new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	imobile=null;
	}

	@Test
	public void testAllDetails() {
		try {
			assertNotNull(imobile.showAllDetails());
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	@Test
	public void testGetDelete() throws MobileException{
		try {
			assertTrue("Check Your ID",imobile.deleteMobile(1001));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
		@Test
		public void testGetSearch() throws MobileException{
			try {
				assertNotNull(imobile.searchMyRange(12000,50000));
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			
		}
			
		@Test
		public void testUpdateQuant() {
			try {
				assertNotNull(imobile.updateQty(1005,12));
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
		
	}
	


