package com.cg.mobilepurchasesystem.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilepurchasesystem.dao.CustomerDaoImpl;
import com.cg.mobilepurchasesystem.dao.ICustomerDao;
import com.cg.mobilepurchasesystem.dao.IMobileDao;
import com.cg.mobilepurchasesystem.dao.MobileDaoImpl;
import com.cg.mobilepurchasesystem.dto.Customer;
import com.cg.mobilepurchasesystem.dto.Mobile;
import com.cg.mobilepurchasesystem.exception.MobileException;

public class TestCustomerDaoImpl {

	ICustomerDao icustomer;
	Customer c;
	Mobile m;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
	}

	@Before
	public void setUp() throws Exception {
		icustomer=new CustomerDaoImpl();
		c=new Customer();
		m=new Mobile();
	}

	@After
	public void tearDown() throws Exception {
		icustomer=null;
	}

	@Test
	public void testAddCustomer() {
		try {
			assertNotNull(icustomer.addCustomer(c, "Sony xperia C"));
		} catch (MobileException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetId() throws MobileException {
		assertNotNull(icustomer.getId());
	}

	@Test
	public void testGetMid() throws MobileException {
		assertNotNull(icustomer.getMid("Samsung Galaxy IV"));
		
		
	}

}
