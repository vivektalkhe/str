

package com.cg.mobilepurchasesystem.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.cg.mobilepurchasesystem.exception.MobileException;

public class DbUtil {
	private static final Logger mylogger = Logger.getLogger(DbUtil.class);
	static Properties prop = null;
	static InputStream in = null;
	static Connection conn = null;

	public static Properties getproperty() throws MobileException {
		prop = new Properties();
		try {
			in = new FileInputStream("res\\oracle.properties");                   //READ THE PROPERTIES FILE 
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			prop.load(in);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("properties file not found");
		} finally {
			if (prop != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return prop;

	}

	public static Connection getConnection() throws MobileException {
		prop = getproperty();

		String driver = prop.getProperty("oracle.driver");
		String url = prop.getProperty("url");
		String uname = prop.getProperty("uname");
		String upass = prop.getProperty("upass");
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			conn = DriverManager.getConnection(url, uname, upass);
			mylogger.info("Connection Esablished.....");
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			mylogger.error("Connection Not Esablished....." + e);
			throw new MobileException("Connection not established");
		}

		return conn;

	}
public static void main(String[] args) {
	try {
		getConnection();
	} catch (MobileException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
