package com.cg.mobilepurchasesystem.dao;

import com.cg.mobilepurchasesystem.dto.Customer;
import com.cg.mobilepurchasesystem.exception.MobileException;

public interface ICustomerDao {
	
	Customer addCustomer(Customer c,String mname) throws MobileException;
	int getId() throws MobileException;
	int getMid(String mname) throws MobileException;

}
