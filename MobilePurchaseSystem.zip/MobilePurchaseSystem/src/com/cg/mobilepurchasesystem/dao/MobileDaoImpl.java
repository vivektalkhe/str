package com.cg.mobilepurchasesystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.mobilepurchasesystem.dto.Mobile;
import com.cg.mobilepurchasesystem.exception.MobileException;
import com.cg.mobilepurchasesystem.util.DbUtil;
import com.sun.xml.internal.fastinfoset.tools.PrintTable;

public class MobileDaoImpl implements IMobileDao {
	Connection conn;
	PreparedStatement ps;
	ResultSet rs;
	
	static CustomerDaoImpl icust=new CustomerDaoImpl();

	public List<Mobile> showAllDetails() throws MobileException {
		conn = DbUtil.getConnection();				
		
		List<Mobile> mlist = new ArrayList<Mobile>();

		String query = "Select * from mobiles";
		try {
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			//ResultSetMetaData rsmd = rs.getMetaData();
			
			//int columnsNumber = rsmd.getColumnCount();
			while (rs.next()) {
				
				
				int m_id = rs.getInt("mobileid");
				String m_name = rs.getString("name");
				double m_price = rs.getInt("price");
				int m_quantity = rs.getInt("quantity");
				Mobile m = new Mobile();
				m.setMobileid(m_id);
				m.setMname(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_quantity);
				mlist.add(m);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("No Record Found");
		} finally {
			try {
				rs.close();
				ps.close();

				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return mlist;
	}

	public boolean deleteMobile(int mobileid) throws MobileException {
		conn = DbUtil.getConnection();
		int rec = 0;
		String query = "delete mobiles where mobileid=?";
		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, mobileid);
			
			rec = ps.executeUpdate();
			if (rec > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
			throw new MobileException("No Record deleted");
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return false;
	}

	public List<Mobile> searchMyRange(int start, int end)
			throws MobileException {
		conn = DbUtil.getConnection();
		List<Mobile> srlist = new ArrayList<Mobile>();
		String query = "select * from mobiles where price between ? and ?";
		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, start);
			ps.setInt(2, end);
			rs = ps.executeQuery();
			while (rs.next()) {
				int m_id = rs.getInt("mobileid");
				String m_name = rs.getString("name");
				int m_price = rs.getInt("price");
				int m_quantity = rs.getInt("quantity");
				Mobile m = new Mobile();
				m.setMobileid(m_id);
				m.setMname(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_quantity);
				srlist.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("No Record deleted");
		} finally {
			try {
				rs.close();
				ps.close();

				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return srlist;
	}

	public boolean updateQty(int mobileid, int quantity) throws MobileException {
		
		conn = DbUtil.getConnection();
		String query="UPDATE MOBILES set quantity=quantity-? where mobileid=?";
		int rec=0;
		try {
			ps=conn.prepareStatement(query);
			ps.setInt(1,quantity);
			ps.setInt(2,mobileid);
			rec=ps.executeUpdate();
			if(rec>0)
			{
				System.out.println("data is updated successfully");
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Data is not updated properly");
		}
		finally
		
		{
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		
		return false;
	}

public boolean checkQuant(int q,String mname) throws MobileException {
	int quant=0;
	int mid=0;
	Scanner sc=new Scanner(System.in);
	conn = DbUtil.getConnection();
	String query1="select quantity from mobiles where mobileid=?";
	mid=icust.getMid(mname);
	try {
		ps=conn.prepareStatement(query1);
		ps.setInt(1,mid);
		rs=ps.executeQuery();
		while(rs.next())
		{
			quant=rs.getInt("quantity");
			
			
		}
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	if(quant>0 &&  quant>=q)
	{
		return true;
	}
	else
	{
		return false;
	}
}
	
}

