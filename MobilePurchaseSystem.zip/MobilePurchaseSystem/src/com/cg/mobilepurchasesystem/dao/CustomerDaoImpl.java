package com.cg.mobilepurchasesystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.mobilepurchasesystem.dto.Customer;
import com.cg.mobilepurchasesystem.dto.Mobile;
import com.cg.mobilepurchasesystem.exception.MobileException;
import com.cg.mobilepurchasesystem.util.DbUtil;

public class CustomerDaoImpl implements ICustomerDao {
	Connection conn;
	PreparedStatement ps;
	ResultSet rs;
	static Mobile m = new Mobile();
	static MobileDaoImpl imobile=new MobileDaoImpl();
	public Customer addCustomer(Customer c,String mname) throws MobileException {

		conn = DbUtil.getConnection();
		int rec = 0;
		int pid = 0;
		int mid = 0;
	
		String query = "Insert into purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) "
				+ "values(?,?,?,?,sysdate,?)";
		try {
			pid = getId();
			mid = getMid(mname);
			ps = conn.prepareStatement(query);
			ps.setInt(1, pid);
			ps.setString(2, c.getCustomername());
			ps.setString(3, c.getMailid());
			ps.setString(4, c.getPhonenumber());
			ps.setInt(5, mid);
			rec = ps.executeUpdate();

			/*
			 * String seq="Select cust_purchase.currval from dual";
			 * ps=conn.prepareStatement(seq); rs=ps.executeQuery();
			 * while(rs.next()) { pid=rs.getInt(1); }
			 */

			if (rec == 1) {
				System.out.println("record inserted successfully");
				imobile.updateQty(mid, 1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("No Records Inserted");
		}

		return c;
	}

	public int getId() throws MobileException {
		int id = 0;

		conn = DbUtil.getConnection();
		String query = "SELECT cust_purchase.NEXTVAL FROM DUAL";
		try {
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				id = rs.getInt(1);
			
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("No Sequence Created");
		}
		
		return id;

	}

	public int getMid(String mname) throws MobileException {
		conn = DbUtil.getConnection();
		String query = "select mobileid from mobiles where name=?";
		int id = 0;
		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, mname);
			rs = ps.executeQuery();
			while (rs.next()) {
				id = rs.getInt("mobileid");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("No record found for this mobile name");
		}
		return id;

	}

	
}
