package com.cg.mobilepurchasesystem.dto;

import java.util.Date;

public class Customer {
	private String customername;
	private String mailid;
	private String phonenumber;
	private int mobileid;
	
	
	public Customer() {
		super();
	}
	public Customer(String customername, String mailid, String phonenumber,
			int mobileid, int purchaseid) {
		super();
		this.customername = customername;
		this.mailid = mailid;
		this.phonenumber = phonenumber;
		this.mobileid = mobileid;
	
		
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	
	
	@Override
	public String toString() {
		return "Customer [customername=" + customername + ", mailid=" + mailid
				+ ", phonenumber=" + phonenumber + ", mobileid=" + mobileid
				+ ", purchaseid="  + ", purchasedate="
				 + "]";
	}

}
