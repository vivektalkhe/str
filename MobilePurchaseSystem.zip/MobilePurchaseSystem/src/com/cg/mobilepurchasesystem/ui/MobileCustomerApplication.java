/*********************************************************************
 * File                 : MobileCustomerApplication.java
 * Author Name          : Niraj Soni
 * Desc                 : Application Class Of Mobile Purchase System
 * Version              : 1.0
 * Method name			: main() 
 * Last Modified Date   : 28-Feb-2017
 * Change Description   : Description about the changes implemented
 *********************************************************************/
package com.cg.mobilepurchasesystem.ui;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.scene.control.TableRow;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobilepurchasesystem.dto.Customer;
import com.cg.mobilepurchasesystem.dto.Mobile;
import com.cg.mobilepurchasesystem.exception.MobileException;
import com.cg.mobilepurchasesystem.service.CustomerServiceImpl;
import com.cg.mobilepurchasesystem.service.ICustomerService;
import com.cg.mobilepurchasesystem.service.IMobileService;
import com.cg.mobilepurchasesystem.service.MobileServiceImpl;

public class MobileCustomerApplication {
	private static final Logger mylogger = Logger
			.getLogger(MobileCustomerApplication.class);
	static Mobile m = new Mobile();
	static Customer c = new Customer();

	public static void main(String[] args) throws MobileException {
		PropertyConfigurator.configure("log4j.properties"); // Read The Logger
															// Files
		mylogger.info("Application Started");
		IMobileService imobile = new MobileServiceImpl();
		ICustomerService icustomer = new CustomerServiceImpl();

		Scanner scr = new Scanner(System.in);
		int choice = 0;
		do {
			printDetail();

			choice = scr.nextInt();
			switch (choice) {
			case 1: // Add Customer Details
				String custname;
				String mail;
				String phone;
				String mname;
				int pid;

				System.out.println("Enter the Quantity:");
				int q = scr.nextInt();
				scr.nextLine();
				System.out.println("Enter the Mobile Name");
				String mob_name = scr.nextLine();
				boolean check = imobile.checkQuant(q, mob_name);
				if (check == true) {
					scr.nextLine();

					String patt = "[A-Z][a-z\\s]{2,20}";
					System.out.println("Enter Name Of Customer");
					custname = scr.nextLine();
					boolean patternMatchedName = Pattern
							.matches(patt, custname);

					if (!patternMatchedName) {
						mylogger.info("First Letter should be capital OR Total Length Of Charaters Should be less than 20");
						throw new MobileException(
								"First Name Should Be As per Instructions");
					}

					String patt_mail = "^(.+)@(.+)$";
					System.out.println("Enter Customer's MailID");
					mail = scr.nextLine();
					boolean patternMatchedMail = Pattern.matches(patt_mail,
							mail);
					if (!patternMatchedMail) {
						mylogger.info("Mail Should Be In correct format abc@def.gft");
						throw new MobileException(
								"Email Should be as per instructions");
					}

					String patt_phone = "[0-9]{10}";
					System.out.println("Enter Customer's PhoneNumber");
					phone = scr.nextLine();

					boolean patternMatchedPhone = Pattern.matches(patt_phone,
							phone);
					if (!patternMatchedPhone) {
						mylogger.info("Phone should be in digits and it should be of 10");
						throw new MobileException(
								"Phone number should be in proper format");
					}

					System.out.println("Enter Customer's MobileName");
					mname = scr.nextLine();

					c.setCustomername(custname);
					c.setMailid(mail);
					c.setPhonenumber(phone);

					try {

						icustomer.addCustomer(c, mname);

					} catch (MobileException e) {
						e.printStackTrace();
					}

				} else {
					throw new MobileException("Check Your Quantity");
				}

				break;
			case 2:// Show All
				List<Mobile> mob = null;

				try {
					mob = imobile.showAllDetails();
				} catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				for (Mobile mobile : mob) {

					// System.out.print(mobile.getMobileid()+"  "+mobile.getMname()+"      "+mobile.getPrice()+" "+mobile.getQuantity());
					System.out.println(mobile);
				}

				break;
			case 3:// Search Employees
				List<Mobile> mobsearch = null;

				System.out.println("Enter The Starting Range Of Price");
				int start = scr.nextInt();

				System.out.println("Enter The Ending Range OF Price");
				int end = scr.nextInt();
				try {
					mobsearch = imobile.searchMyRange(start, end);
					for (Mobile m : mobsearch) {
						System.out.println(m);
					}
				} catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:// Remove Employees
				System.out
						.println("Enter The ID Of Record That You Want To Remove");
				int id = scr.nextInt();
				try {
					imobile.deleteMobile(id);
				} catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 5://Exit
				System.out.println("Exit");
				mylogger.info("Application ended");
				System.exit(10);

				break;

			default:
				break;
			}

		} while (choice != 5);
	}

	public static void printDetail() {
		System.out.println("**********");
		System.out.println("1. Add Customer Deatils ");
		System.out.println("2. Show All Mobile Details");
		System.out.println("3. Search Mobile Based On Price Range");
		System.out.println("4. Remove Mobile Details");
		System.out.println("5. Exit");
		System.out.println("***********");
	}
}
