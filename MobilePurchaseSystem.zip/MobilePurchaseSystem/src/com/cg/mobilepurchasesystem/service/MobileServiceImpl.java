package com.cg.mobilepurchasesystem.service;

import java.util.List;

import com.cg.mobilepurchasesystem.dao.MobileDaoImpl;
import com.cg.mobilepurchasesystem.dto.Mobile;
import com.cg.mobilepurchasesystem.exception.MobileException;

public class MobileServiceImpl implements IMobileService{
MobileDaoImpl impl=new MobileDaoImpl();
	public List<Mobile> showAllDetails() throws MobileException {
		return impl.showAllDetails();
		
	}

	public boolean deleteMobile(int mobileid) throws MobileException {
		
		return impl.deleteMobile(mobileid);
	}

	public List<Mobile> searchMyRange(int start, int end)
			throws MobileException {
	
		return impl.searchMyRange(start, end);
	}

	public boolean updateQty(int mobileid, int quantity) throws MobileException {
		// TODO Auto-generated method stub
		return impl.updateQty(mobileid, quantity);
	}

	public boolean checkQuant(int q,String mname) throws MobileException {
		// TODO Auto-generated method stub
		return impl.checkQuant(q,mname);
	}
	

}
