package com.cg.mobilepurchasesystem.service;

import com.cg.mobilepurchasesystem.dto.Customer;
import com.cg.mobilepurchasesystem.exception.MobileException;

public interface ICustomerService {
	Customer addCustomer(Customer c,String mname) throws MobileException;
	int getId() throws MobileException;
	


}
