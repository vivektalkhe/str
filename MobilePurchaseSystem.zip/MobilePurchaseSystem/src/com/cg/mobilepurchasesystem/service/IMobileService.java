package com.cg.mobilepurchasesystem.service;

import java.util.List;

import com.cg.mobilepurchasesystem.dto.Mobile;
import com.cg.mobilepurchasesystem.exception.MobileException;

public interface IMobileService {
	List<Mobile> showAllDetails() throws MobileException;
	boolean deleteMobile(int mobileid) throws MobileException;
	List<Mobile> searchMyRange(int start,int end) throws MobileException;
	boolean updateQty(int mobileid, int quantity) throws MobileException; 
	boolean checkQuant(int q,String mname) throws MobileException;
}
