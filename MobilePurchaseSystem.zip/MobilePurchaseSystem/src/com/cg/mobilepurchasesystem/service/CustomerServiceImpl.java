package com.cg.mobilepurchasesystem.service;

import com.cg.mobilepurchasesystem.dao.CustomerDaoImpl;
import com.cg.mobilepurchasesystem.dao.ICustomerDao;
import com.cg.mobilepurchasesystem.dto.Customer;
import com.cg.mobilepurchasesystem.exception.MobileException;

public class CustomerServiceImpl implements ICustomerService {
	 ICustomerDao cust=new CustomerDaoImpl();
	
	public int getId() throws MobileException {
		// TODO Auto-generated method stub
		return cust.getId();
	}
	public int getMid(String mname) throws MobileException {
		// TODO Auto-generated method stub
		return cust.getMid(mname);
	}
	public Customer addCustomer(Customer c, String mname)
			throws MobileException {
		// TODO Auto-generated method stub
		return cust.addCustomer(c, mname);
	}

}
