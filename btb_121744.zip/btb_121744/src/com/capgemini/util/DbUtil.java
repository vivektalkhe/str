/*********************************************************************
 * File                 : DbUtil.java
 * Author Name          : Niraj Soni
 * Desc                 : File To Connect To Database
 * Version              : 1.0
 * Method name			: getProperty(),getConnection() 
 * Throws				: BookingException()
 * Last Modified Date   : 28-Feb-2017
 * Change Description   : Description about the changes implemented
 *********************************************************************/

package com.capgemini.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.capgemini.exception.BookingException;



public class DbUtil {
	private static final Logger mylogger = Logger.getLogger(DbUtil.class);
	static Properties prop = null;
	static InputStream in = null;
	static Connection conn = null;

	public static Properties getproperty() throws BookingException {
		prop = new Properties();
		try {
			in = new FileInputStream("res//oracle.properties");                   //READ THE PROPERTIES FILE 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			prop.load(in);
			mylogger.info("PROPERTIES FILE READ SUCCESSFULLY....");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mylogger.info("PROPERTIES FILE IS NOT READABLE....");
			throw new BookingException("Properties File Not Found");
		} finally {
			if (prop != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return prop;

	}

	public static Connection getConnection() throws BookingException {
		prop = getproperty();											//Calling getproperty() Method

		String driver = prop.getProperty("oracle.driver");
		String url = prop.getProperty("url");
		String uname = prop.getProperty("uname");
		String upass = prop.getProperty("upass");
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			conn = DriverManager.getConnection(url, uname, upass);			
			mylogger.info("Connection Esablished.....");
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			mylogger.error("Connection Not Esablished....." + e);
			throw new BookingException("Connection not established");
		}

		return conn;

	}

}

