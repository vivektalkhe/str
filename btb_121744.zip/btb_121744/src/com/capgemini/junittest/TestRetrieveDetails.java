package com.capgemini.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;

public class TestRetrieveDetails {

	BusDao impl;
	BusBean bus;
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		impl=new BusDaoImpl();
		bus=new BusBean();
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testRetrieveBusDetails() throws BookingException {
		try {
			assertNotNull(impl.retrieveBusDetails());
		} catch (BookingException e) {
			// TODO Auto-generated catch block
		throw new BookingException("data is not retrived properly");
		}
	}

}
