/***********************************************************************************************
 * File                 : BookingException.java
 * Author Name          : Niraj Soni
 * Desc                 : Program To Handle Exception and Provide User Defined Messages
 * Version              : 1.0
 * Method name			: getProperty(),getConnection() 
 * Throws				: BookingException()
 * Last Modified Date   : 28-Feb-2017
 * Change Description   : Description about the changes implemented
 ***********************************************************************************************/

package com.capgemini.exception;

public class BookingException extends Exception {

	public BookingException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public BookingException(String msg)
	{
		super(msg);
	}
}
