package com.capgemini.client;

import java.util.Scanner;

import com.capgemini.bean.BookingBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.BusService;
import com.capgemini.service.BusServiceImpl;


public class MainClient {
	static BookingBean booking=new BookingBean(); 
	public static void main(String[] args) throws BookingException {
		BusService bus = new BusServiceImpl();
		int choice = 0;
		
		Scanner scanner = new Scanner(System.in);
		do {
			bookDetail();

			choice = scanner.nextInt();
			switch (choice) {
			case 1://Inserting Book Details
				String custId;
				int busId;
				int noOfSeats;
				scanner.nextLine();
				String pattCustId="^[A-Z]{1}[0-9]{6}$";
				System.out.println("Enter Customer ID");
				custId=scanner.nextLine();
				
				BusServiceImpl.validateName(pattCustId,custId);
				
				System.out.println("Enter Bus ID");
				busId=scanner.nextInt();
				
				System.out.println("Enter No Of Seats To Book");
				noOfSeats=scanner.nextInt();
				
				booking.setBusId(busId);
				booking.setCustId(custId);
				booking.setNoOfSeat(noOfSeats);
				try {
					bus.bookTicket(booking);
				} catch (BookingException e) {
					
					e.printStackTrace();
					throw new BookingException("Check Your Data");
				}
				
				break;
				
			case 2://Exit
				System.out.println("Exit");
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
		} while (choice != 2);

	}

	public static void bookDetail() {
		System.out.println("**********");
		System.out.println("1. Book Ticket ");
		System.out.println("2. Exit");
		System.out.println("***********");
	}
}
