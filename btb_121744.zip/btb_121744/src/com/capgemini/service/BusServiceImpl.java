package com.capgemini.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;


public class BusServiceImpl implements BusService {
	BusDao bus=new BusDaoImpl();
	@Override
	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {
		// TODO Auto-generated method stub
		return bus.retrieveBusDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		return bus.bookTicket(bookingBean);
	}

	public static void validateName
	(String patt,String name) throws BookingException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new BookingException("CustomerID  Should Have First letter capital and then six digits");
	}
		
	}
}
