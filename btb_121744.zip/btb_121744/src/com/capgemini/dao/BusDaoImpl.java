package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.DbUtil;

public class BusDaoImpl implements BusDao {

	
	
 BookingBean bookingbean=new BookingBean(); 
	@Override
	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {
		Connection  conn = DbUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		ArrayList<BusBean> buslist = new ArrayList<BusBean>();
		String showQuery = "SELECT * FROM BUSDETAILS";
		try {
			ps = conn.prepareStatement(showQuery);
			rs = ps.executeQuery();

			while (rs.next()) {
				int busId = rs.getInt("busId");
				String busType = rs.getString("BusType");
				Date journeydate = rs.getDate("dateOfJourney");
				String d = journeydate.toString();
				// DateTimeFormatter formatter =
				// DateTimeFormatter.ofPattern("DD-MON-YYYY");
				LocalDate Journey = LocalDate.parse(d);
				String fromStop = rs.getString("FromStop");
				String toStop = rs.getString("ToStop");
				int availableSeats = rs.getInt("availableSeats");
				double fare = rs.getDouble("fare");

				BusBean bus = new BusBean();
				bus.setBusId(busId);
				bus.setBusType(busType);
				bus.setDateOfJourney(Journey);
				bus.setFromStop(fromStop);
				bus.setToStop(toStop);
				bus.setAvailableSeats(availableSeats);
				bus.setFare(fare);
				buslist.add(bus);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
				try {
					ps.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		
		
		return buslist;
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		int rec = 0;
		int bookingId = 0;
		Connection  conn = DbUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		String insertQuery = "INSERT INTO BookingDetails VALUES(?,?,?,?)";

		try {
			bookingId = getBookId();
			ps = conn.prepareStatement(insertQuery);
			ps.setInt(1, bookingId);
			ps.setString(2, bookingBean.getCustId());
			System.out.println(bookingBean.getCustId());
			ps.setInt(3, bookingBean.getBusId());
			ps.setInt(4, bookingBean.getNoOfSeat());
		System.out.println(bookingId+" "+bookingBean.getCustId()+" " +getBookId());
			boolean check = checkSeats(bookingBean.getNoOfSeat(),bookingBean.getBusId());
			
			
	System.out.println(check);
			if (check == true) {
				rec = ps.executeUpdate();
				if (rec>0) {
					System.out.println("Thank You.Your Booking ID IS"
							+ bookingId);
					System.out.println("Record Inserted Successfully");

					updateSeat(bookingBean.getBusId(),
							bookingBean.getNoOfSeat());
				}
			} else {
				throw new BookingException("Sorry No Seats Are Available");
			}
		} catch (SQLException e) {
			System.out.println(e);
			throw new BookingException("Record Can Not Insert Successfully");
		} 
		
		finally{
			
			
				try {
					ps.close();
				
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		
		return bookingId;
		
	
	}

	public int getBookId() throws BookingException {
		int id = 0;

		Connection  conn = DbUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query = "SELECT Booking_Id_Seq.NEXTVAL FROM DUAL";
		try {
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				id = rs.getInt(1);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BookingException("No Sequence Created");
		} 
		finally{
			
			
			try {
				ps.close();
				rs.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return id;

	}

	public boolean checkSeats(int seats, int id) throws BookingException {
		int busSeat = 0;
		int mid = 0;
		Scanner sc = new Scanner(System.in);
		Connection  conn = DbUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query1 = "SELECT AVAILABLESEATS FROM BUSDETAILS WHERE BUSID=?";

		try {
			ps = conn.prepareStatement(query1);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				busSeat = rs.getInt("AVAILABLESEATS");

			}
			if (busSeat > 0 && busSeat >= seats) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} finally{
			try {
				ps.close();
				rs.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	return false;
	}

	public boolean updateSeat(int busid, int seats) throws BookingException {

		Connection  conn = DbUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query = "UPDATE BUSDETAILS SET AVAILABLESEATS=AVAILABLESEATS-? WHERE BUSID=?";
		int rec = 0;
		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, busid);
			ps.setInt(2, seats);
			rec = ps.executeUpdate();
			if (rec > 0) {
				System.out.println("data is updated successfully");
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BookingException("Data is not updated properly");
		} 
		finally{
			try {
				ps.close();
			
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

}
